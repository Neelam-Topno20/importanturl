package com.cg.banking.clients;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingService;
import com.cg.banking.services.BankingServiceImpl;
public class MainClass {
	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		 BankingService bankingService=new BankingServiceImpl();
		/*long accountId=bankingService.openAccount("Saving",2589);
		System.out.println(accountId);*/
		
		//bankingService.depositAmount(2024225153,1000);
		//bankingService.withdrawAmount(2024225153,1000);
		//bankingService.fundTransfer(2024225152, 2024225153, 2000);
		//Account account=bankingService.getAccountDetails(2024225153);
		//System.out.println(account.toString());
		/*List<Account> list=new ArrayList<Account>();
		list =bankingService.getAllAccountDetails();
		for(Account str:list)
			System.out.println(str.toString());*/
		/*List<Transaction> list=new ArrayList<Transaction>();
		list=bankingService.getAccountAllTransaction(2024225152);
		for(Transaction str:list)
			System.out.println(str.toString());*/
		
		/*List<Transaction> list=new ArrayList<Transaction>();
		list=bankingService.getAllTransactionDetails();
		for(Transaction str:list)
			System.out.println(str.toString());*/
		
		//Account account=new Account("Saving",5000,new Customer("Ashav Kumar","ashav21011996@gmail.com","Pune","HHTPK0434B"));
		//String accString=bankingService.openAccount("Ashav Kumar","ashav21011996@gmail.com","Pune","HHTPK0434B","Saving",5000);
		 /*Account account=new Account();
		 List<Account> list=new ArrayList<Account>();
		 list.add(account);

		 Customer customer=new Customer(,);*/
		 //bankingService.openAccount("Ashav","ashav2101@gmail.com","Pune","HHTPK0434B","Saving",1500,"Cricket");
		 //bankingService.depositAmount("1469");
		//System.out.println(accString);
	}
}
