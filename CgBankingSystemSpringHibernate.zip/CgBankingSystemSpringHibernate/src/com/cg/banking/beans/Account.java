package com.cg.banking.beans;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
/*@NamedQueries({
	@NamedQuery(name="getAllAccount",query="select a from Account a")
})*/
@Entity
@SequenceGenerator(name="seqAccount" ,  allocationSize=1)
public class Account {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE ,generator="seqAccount")
	private long accountNo;
	private String accountType;
	private float accountBalance;
	@ManyToOne
	private Customer customer;
	@OneToMany(mappedBy="account",cascade=CascadeType.ALL)
	private  List<Transaction> transaction;
	public Account() {
		super();
	}
	public Account(String accountType, float accountBalance) {
		super();
		this.accountType = accountType;
		this.accountBalance = accountBalance;
	}
	public Account(long accountNo,String accountType, float accountBalance) {
		super();
		this.accountNo=accountNo;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
	}
	public Account(String accountType, float accountBalance, Customer customer) {
		super();
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.customer = customer;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public List<Transaction> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<Transaction> transaction) {
		this.transaction = transaction;
	}
}
