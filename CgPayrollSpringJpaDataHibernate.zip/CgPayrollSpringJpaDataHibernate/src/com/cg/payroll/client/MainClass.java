package com.cg.payroll.client;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {

	public static void main(String[] args)throws PayrollServicesDownException, AssociateDetailNotFoundException {

		ApplicationContext context=new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollservices=(PayrollServices) context.getBean("payrollServices") ;
		/*int associateID=payrollservices.acceptAssociateDetails("Neelam", "Topno", "neelam@gmail.com", "YTP", "Sr.analyst", "GSHDA2345F", 20000, 17300, 2000, 2000, 5336355, "ICICI", "ICIC0000985");
		System.out.println(associateID);
		payrollservices.calculateNetSalary(associateID);
		Associate associate = payrollservices.getAssociateDetails(associateID);
		System.out.println(associate.toString());*/
		/*
		ArrayList<Associate> associateList=payrollservices.getAllAssociateDetails();
		for (Associate associate2 : associateList) 
			System.out.println(associate2.toString());*/
		int associateID=payrollservices.acceptAssociateDetails("Neelam", "Topno", "neelam@gmail.com", "YTP", "Sr.analyst", "GSHDA2345F", 20000, 17300, 2000, 2000, 5336355, "ICICI", "ICIC0000985");
		System.out.println(associateID);
		
		/*ArrayList<Associate> associateList=payrollservices.getAllAssociateDetails();
		for (Associate associate2 : associateList) 
			System.out.println(associate2.toString());*/
		
		ArrayList<Associate> associateList=	payrollservices.findFewAssociate(30000);

		for (Associate associate2 : associateList) 
			System.out.println(associate2.toString());
			
		System.out.println("hello");

	}


}
