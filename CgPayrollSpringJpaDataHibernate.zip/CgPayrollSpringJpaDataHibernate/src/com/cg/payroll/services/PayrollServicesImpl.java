package com.cg.payroll.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;


@Component(value="payrollServices")
public class PayrollServicesImpl implements PayrollServices{
	@Autowired
	private AssociateDAO associateDAO;
	
	public PayrollServicesImpl(AssociateDAO associateDAO) {
		super();
		this.associateDAO = associateDAO;
	}

	public PayrollServicesImpl() {
		
	}

		@Override
		public int acceptAssociateDetails(String firstName, String lastName,String emailId, String department, String designation,String pancard,
				double yearlyInvestmentUnder80C, double basicSalary, double epf, double companyPf,
				long accountNumber, String bankName, String ifscCode)throws PayrollServicesDownException {
			
			
			try {
				Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId,  new BankDetails(accountNumber, bankName, ifscCode), new Salary(basicSalary, epf, companyPf));
				associate=associateDAO.save(associate);
				return associate.getAssociateID();
				
			} catch (Exception e) {
				e.getMessage();
				//logger.error(e.getMessage()+" "+e.getCause());
				throw new PayrollServicesDownException("Services down please try again",e);//wrapper exception 
			}
			
		
		}
		
	
	
	@Override
	public double calculateNetSalary(int associateId)
			throws AssociateDetailNotFoundException,
			PayrollServicesDownException {
		Associate associate =getAssociateDetails(associateId);
		if(associate==null) throw new AssociateDetailNotFoundException("Associate Details Not Found");
		
		//tax calculation code
	double basicSalary= associate.getSalary().getBasicSalary();
		
		double hra=50*basicSalary/100;
		associate.getSalary().setHra(hra);
		//updateValue("hra",hra,associateId);
		
		double conveyenceAllowance=25*basicSalary/100;
		associate.getSalary().setConveyenceAllowance(conveyenceAllowance);
		//updateValue("conveyanceAllowance",conveyenceAllowance,associateId);
		
		double otherAllowance=25*basicSalary/100;
		associate.getSalary().setOtherAllowance(otherAllowance);
		
		double personalAllowance=40*basicSalary/100;
		associate.getSalary().setPersonalAllowance(personalAllowance);
		
		double epf=12*basicSalary/100;
		associate.getSalary().setEpf(epf);
		
		
		double companyPf = 12*basicSalary/100;
		associate.getSalary().setCompanyPf(companyPf);
		
		double  gratuity=481*basicSalary/10000;
		associate.getSalary().setGratuity(gratuity);
		
		double  grossSalary=basicSalary+conveyenceAllowance+otherAllowance+personalAllowance+epf;
		associate.getSalary().setGrossSalary(grossSalary);
		
		double yearlyInvestmentUnder80C = epf+associate.getYearlyInvestmentUnder80C();
		if(yearlyInvestmentUnder80C>150000)
			yearlyInvestmentUnder80C=150000;
		associate.setYearlyInvestmentUnder80C(yearlyInvestmentUnder80C);
		
		double taxableIncome = 12*(grossSalary-epf)-yearlyInvestmentUnder80C;
		double yearlyTax=0;
		if(taxableIncome<=250000)
			yearlyTax=0;
		else if(taxableIncome>250000 && taxableIncome<=500000)
			yearlyTax=5*(taxableIncome-250000)/100;
		else if(taxableIncome>500000 && taxableIncome<=1000000)
			yearlyTax=12500+20*(taxableIncome-500000);
		else
			yearlyTax=112500+30*(taxableIncome-1000000);
		double monthlyTax=yearlyTax/12;
		associate.getSalary().setMonthlyTax(monthlyTax);
		
		double netSalary=grossSalary-epf-monthlyTax;
		associate.getSalary().setNetSalary(netSalary);
		
		if(associateDAO.save(associate) != null)
			System.out.println("associate updated ");
		else
			System.out.println("associate not updated");
		
		return netSalary;
	}

	@Override
	public Associate  getAssociateDetails(int associateId) throws AssociateDetailNotFoundException,PayrollServicesDownException {
		Associate associate;
		try {
			associate = associateDAO.findOne(associateId);
			if(associate==null)
				throw new AssociateDetailNotFoundException("Associate Details Not Found");
			else
				return associate;
		} 
		catch (Exception e) {
			e.printStackTrace();
			//logger.error(e);
			throw new PayrollServicesDownException("Services down please try again",e);
		}
		
	
	}

	@Override
	public  ArrayList<Associate> getAllAssociateDetails()
			throws PayrollServicesDownException {
		
		try {
			return (ArrayList<Associate>) associateDAO.findAll();
		} catch (Exception e) {
			e.printStackTrace();
			//logger.error(e);
			throw new PayrollServicesDownException("Services down please try again",e);
		}
		
	}
	
	@Override
	public ArrayList<Associate> findFewAssociate(double yearlyInvestmentUnder8oC) {
				return associateDAO.findFewAssociate(yearlyInvestmentUnder8oC);
	}

}
