package com.cg.payroll.services;

import java.util.ArrayList;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

public interface PayrollServices {
	int acceptAssociateDetails(String firstName, String lastName,
			String emailId, String department, String designation,
			String pancard, double yearlyInvestmentUnder80C,double basicSalary,
			double epf, double companyPf, long accountNumber, String bankName,
			String ifscCode)throws PayrollServicesDownException;
	
	double calculateNetSalary(int associateId)throws AssociateDetailNotFoundException,PayrollServicesDownException;
	
	Associate getAssociateDetails(int associateId)throws AssociateDetailNotFoundException,PayrollServicesDownException;
	
	ArrayList<Associate> getAllAssociateDetails()throws PayrollServicesDownException;
	
	
}
